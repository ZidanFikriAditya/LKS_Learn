<template>
  <div>
    Hallo
  </div>
</template>

<script>
  export default {
    name: 'Home'
  }
</script>