<template>
  <div>
    Product
  </div>
</template>

<script>
  export default {
    name: 'Product'
  }
</script>