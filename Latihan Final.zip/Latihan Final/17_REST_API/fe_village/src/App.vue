<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
import router from "@/routes/web";

export default {
  name: 'App',
  router
}
</script>

